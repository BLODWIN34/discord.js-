import type { Constructor, Event, Member, Method } from './index.js';

export type ChildTypes = Constructor | Member | Method | Event;
