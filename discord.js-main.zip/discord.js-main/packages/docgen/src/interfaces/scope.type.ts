export type Scope = 'global' | 'instance' | 'static';
