export interface Config {
	input: string[];
	custom: string;
	root: string;
	output: string;
	typescript: boolean;
}
