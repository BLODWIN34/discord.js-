export interface Type {
	names?: string[];
}
