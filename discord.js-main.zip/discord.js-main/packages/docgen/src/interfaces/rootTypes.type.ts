import type { Class, External, Interface, Method, Typedef } from './index.js';

export type RootTypes = Class | Method | Interface | Typedef | External;
