export type Access = 'public' | 'private' | 'protected';
