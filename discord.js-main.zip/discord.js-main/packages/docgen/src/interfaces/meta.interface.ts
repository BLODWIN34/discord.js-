export interface Meta {
	lineno: number;
	filename: string;
	path: string;
}
