export interface Item {
	id: string;
	longname: string;
	name: string;
	kind: string;
	description: string;
	order: number;
	ignore?: boolean;
}
