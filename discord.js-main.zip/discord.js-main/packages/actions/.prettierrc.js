module.exports = require('../../.prettierrc.json');
